NEXUS_OFC — SITE DA PADARIA

Arquivos:
- index.html
- style.css
- script.js

Como usar:
1. Extraia o ZIP.
2. Abra o arquivo index.html no navegador.

Personalização:
- Edite endereço, telefone e horário em index.html.
- Troque o número do WhatsApp no link wa.me em index.html e script.js.
- Os produtos e preços ficam no início do script.js.
