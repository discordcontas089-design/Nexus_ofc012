const products=[
{name:"Pão Francês",cat:"paes",price:1.2,emoji:"🥖",desc:"Crocante por fora e macio por dentro."},
{name:"Croissant",cat:"paes",price:7.5,emoji:"🥐",desc:"Folhado, dourado e amanteigado."},
{name:"Pão de Queijo",cat:"paes",price:4.5,emoji:"🧀",desc:"Quentinho e irresistível."},
{name:"Bolo de Chocolate",cat:"doces",price:12.9,emoji:"🍫",desc:"Fatia generosa com cobertura cremosa."},
{name:"Sonho",cat:"doces",price:6.5,emoji:"🍩",desc:"Massa leve com recheio cremoso."},
{name:"Torta de Morango",cat:"doces",price:14.9,emoji:"🍓",desc:"Creme suave e morangos frescos."},
{name:"Coxinha",cat:"salgados",price:7.0,emoji:"🥟",desc:"Massa crocante e recheio saboroso."},
{name:"Empada",cat:"salgados",price:6.0,emoji:"🥧",desc:"Massa amanteigada e recheio especial."},
{name:"Café Expresso",cat:"bebidas",price:5.0,emoji:"☕",desc:"Intenso, aromático e preparado na hora."},
{name:"Cappuccino",cat:"bebidas",price:8.5,emoji:"☕",desc:"Café, leite e espuma na medida."},
{name:"Suco de Laranja",cat:"bebidas",price:7.0,emoji:"🍊",desc:"Natural e refrescante."},
{name:"Chocolate Quente",cat:"bebidas",price:9.0,emoji:"🍵",desc:"Cremoso e perfeito para qualquer hora."}
];
let cart=[];
const money=v=>v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
function render(filter="todos"){const el=document.querySelector("#products");el.innerHTML=products.filter(p=>filter==="todos"||p.cat===filter).map((p,i)=>`<article class="product"><div class="product-img">${p.emoji}</div><div class="product-body"><h3>${p.name}</h3><p>${p.desc}</p><span class="price">${money(p.price)}</span><button class="add" onclick="add(${products.indexOf(p)})">+</button></div></article>`).join("")}
function add(i){cart.push(products[i]);updateCart();showToast()}
function updateCart(){document.querySelector("#cartCount").textContent=cart.length;const box=document.querySelector("#cartItems");if(!cart.length){box.innerHTML='<p style="color:#888;padding:20px 0">Seu carrinho está vazio.</p>'}else{box.innerHTML=cart.map((p,i)=>`<div class="cart-row"><span>${p.emoji} ${p.name}<small>${money(p.price)}</small></span><button class="add" onclick="removeItem(${i})">×</button></div>`).join("")}document.querySelector("#cartTotal").textContent=money(cart.reduce((s,p)=>s+p.price,0))}
function removeItem(i){cart.splice(i,1);updateCart()}
function openCart(){document.querySelector("#cartModal").classList.add("show");updateCart()}
function closeCart(){document.querySelector("#cartModal").classList.remove("show")}
function showToast(){const t=document.querySelector("#toast");t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1600)}
function checkout(){if(!cart.length){alert("Adicione algum produto ao carrinho.");return}const text="Olá! Quero fazer um pedido na Nexus_ofc:%0A%0A"+cart.map(p=>`• ${p.name} — ${money(p.price)}`).join("%0A")+"%0A%0ATotal: "+money(cart.reduce((s,p)=>s+p.price,0));window.open("https://wa.me/5500000000000?text="+text,"_blank")}
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");render(b.dataset.filter)}));
document.querySelector(".menu-btn").addEventListener("click",()=>document.querySelector(".nav-links").classList.toggle("open"));
document.querySelectorAll(".nav-links a").forEach(a=>a.addEventListener("click",()=>document.querySelector(".nav-links").classList.remove("open")));
document.querySelector("#cartModal").addEventListener("click",e=>{if(e.target.id==="cartModal")closeCart()});
render();
